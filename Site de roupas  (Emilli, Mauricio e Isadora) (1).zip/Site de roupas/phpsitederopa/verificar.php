<?php
    $nome = $_POST['nomeCompleto'];
    $telefone = $_POST['telefone'];
    $email = $_POST['email'];
    $datadenascimento = $_POST['datadenascimento'];
    $mensagem = $_POST['mensage'];

    echo "Meu nome é $nome <hr>";
    echo "Minha data de nascimento é $datadenascimento <hr>";
    echo "Meu telefone é $telefone <hr>";
    echo "Meu email é $email <hr>";
    echo  "$mensagem <hr>";


?>