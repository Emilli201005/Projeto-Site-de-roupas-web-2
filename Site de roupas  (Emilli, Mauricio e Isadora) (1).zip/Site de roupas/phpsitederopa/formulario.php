<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>phpsitederoupa</title>
</head>
<body>
    <form action="verificar.php" method="post">
        <label>Nome Completo</label> <br>
        <input type="text" placeholder="Digite o seu nome" required name="nomecompleto"> <br>
        <label>Telefone</label> <br>
        <input type="tel" placeholder="Digite o seu telefone" name="telefone"> <br>
        <label>Email</label> <br>
        <input type="tel" placeholder="Digite sua data de nascimento" name="datadenascimento"> <br>
        <label>datadenascimento</label> <br>
        <input type="email" placeholder="Digite o seu email" name="email"> <br>
        <label>Mensagem</label> <br>
        <input type="textarea" placeholder="Digite a sua mensagem" name="msg"> <br>
        <input type="submit" value="Enviar">
        <input type="reset" value="Limpar">

    </form>
</body>
</html>